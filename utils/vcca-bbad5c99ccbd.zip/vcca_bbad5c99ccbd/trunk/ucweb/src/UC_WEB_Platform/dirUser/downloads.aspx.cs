﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using UCENTRIK.LIB.Base;


namespace UCENTRIK.WEB.PLATFORM.dirUser
{
    public partial class downloads : UcAppBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
