﻿using System;
using System.Web;

using UCENTRIK.LIB.Base;



namespace SosWeb.dirReport
{
    public partial class SurveyReport : UcAppReportBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
