﻿namespace UCENTRIK.DATASETS {
    
    
    public partial class AgentDS {
        partial class AgentDSDataTable
        {
        }
    }
}

namespace UCENTRIK.DATASETS.AgentDSTableAdapters {
    
    
    public partial class AgentDSTableAdapter {
    }
}
