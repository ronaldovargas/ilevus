﻿namespace UCENTRIK.DATASETS.UserDSTableAdapters
{
}
namespace UCENTRIK.DATASETS.UserDSTableAdapters
{
}
namespace UCENTRIK.DATASETS
{
    
    
    public partial class UserDS {
        partial class UserDSDataTable
        {
        }
    }
}
