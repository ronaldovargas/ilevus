﻿namespace UCENTRIK.DATASETS {
    
    
    public partial class ContactDS {
    }
}
