﻿namespace UCENTRIK.DATASETS {
    
    
    public partial class SkillDS {
        partial class SkillDSDataTable
        {
        }
    }
}

namespace UCENTRIK.DATASETS.SkillDSTableAdapters
{
    partial class SkillDSTableAdapter
    {
    }

    partial class SkillAgentDSTableAdapter
    {
    }
    
    
    public partial class AgentSkillDSTableAdapter {
    }
}
