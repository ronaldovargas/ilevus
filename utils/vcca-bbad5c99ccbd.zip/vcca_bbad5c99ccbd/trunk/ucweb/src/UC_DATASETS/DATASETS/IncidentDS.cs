﻿namespace UCENTRIK.DATASETS.IncidentDSTableAdapters
{
}
namespace UCENTRIK.DATASETS
{
    
    
    public partial class IncidentDS {
        partial class IncidentNoteDSDataTable
        {
        }
    }
}

namespace UCENTRIK.DATASETS.IncidentDSTableAdapters
{
    
    
    public partial class IncidentDSTableAdapter {
    }
}
