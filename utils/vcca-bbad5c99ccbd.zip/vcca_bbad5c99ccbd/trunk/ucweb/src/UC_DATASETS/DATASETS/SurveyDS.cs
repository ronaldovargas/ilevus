﻿namespace UCENTRIK.DATASETS
{
    
    
    public partial class SurveyDS {
        partial class SurveyQuestionDSDataTable
        {
        }
    }
}
