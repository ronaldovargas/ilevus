﻿namespace UCENTRIK.DATASETS {
    
    
    public partial class LogDS {
    }
}

namespace UCENTRIK.DATASETS.LogDSTableAdapters {
    
    
    public partial class LogDSTableAdapter {
    }
}
