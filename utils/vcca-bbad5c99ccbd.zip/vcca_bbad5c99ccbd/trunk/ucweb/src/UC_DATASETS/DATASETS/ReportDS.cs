﻿namespace UCENTRIK.DATASETS
{
    
    
    public partial class ReportDS {
        partial class ReportIncidentDSDataTable
        {
        }
    }
}
