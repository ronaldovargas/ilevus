﻿using System;




namespace UCENTRIK.Configuration
{
    public class UcConfiguration
    {
    }
}
