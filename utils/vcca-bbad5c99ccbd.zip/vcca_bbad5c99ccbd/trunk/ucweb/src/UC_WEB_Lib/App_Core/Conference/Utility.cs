﻿using System;
using System.Collections.Generic;
using System.Web;

namespace UCENTRIK.LIB
{
    public class Utility
    {
        public const string ConferenceStartupParametersSessionVariableName = "ConferenceStartupParametersSessionVariableName";
    }
}
