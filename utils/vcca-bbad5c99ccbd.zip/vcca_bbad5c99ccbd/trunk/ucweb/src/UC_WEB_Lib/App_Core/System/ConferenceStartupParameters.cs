﻿using System;
using System.Collections.Generic;
using System.Web;
//using UCENTRIK.LIB.Properties;

namespace SosWebControlPrototype.Model
{



    //public class ConferenceStartupParameters
    //{
    //    private string _serverUrl;
    //    //private string _sosServerUrl;
    //    private string _userName;
    //    private string _userType;
    //    private string _conferenceName;
    //    private bool _useJavascript;
    //    private bool _shouldStartAppShare = false;
    //    private bool _shouldCreateConference;
    //    private bool _showVideoSelection;
    //    private int _videoWidth;
    //    private int _videoHeight;
    //    private int _videoFPS;
    //    private int _videoBandwidth;
    //    private int _videoQuality;
    //    private int _appSharevideoWidth;
    //    private int _appSharevideoHeight;
    //    private int _appSharevideoFPS;
    //    private int _appSharevideoBandwidth;
    //    private int _appSharevideoQuality;
    //    private bool _sendMicSound;
    //    private bool _receiveSound;
    //    private int _screenVideoWidth;
    //    private int _screenVideoHeight;
    //    private bool _videoTransmitterMode;
    //    private bool _keepAspectRatioForVideo;

    //    public int AppSharevideoWidth
    //    {
    //        get { return _appSharevideoWidth; }
    //        set { _appSharevideoWidth = value; }
    //    }

    //    public int AppSharevideoHeight
    //    {
    //        get { return _appSharevideoHeight; }
    //        set { _appSharevideoHeight = value; }
    //    }

    //    public int AppSharevideoFPS
    //    {
    //        get { return _appSharevideoFPS; }
    //        set { _appSharevideoFPS = value; }
    //    }

    //    public int AppSharevideoBandwidth
    //    {
    //        get { return _appSharevideoBandwidth; }
    //        set { _appSharevideoBandwidth = value; }
    //    }

    //    public int AppSharevideoQuality
    //    {
    //        get { return _appSharevideoQuality; }
    //        set { _appSharevideoQuality = value; }
    //    }

    //    public bool ShouldCreateConference
    //    {
    //        get { return _shouldCreateConference; }
    //        set { _shouldCreateConference = value; }
    //    }

    //    public int VideoWidth
    //    {
    //        get { return _videoWidth; }
    //        set { _videoWidth = value; }
    //    }

    //    public int VideoHeight
    //    {
    //        get { return _videoHeight; }
    //        set { _videoHeight = value; }
    //    }

    //    public int VideoFPS
    //    {
    //        get { return _videoFPS; }
    //        set { _videoFPS = value; }
    //    }

    //    public bool ShouldStartAppShare
    //    {
    //        get { return _shouldStartAppShare; }
    //        set { _shouldStartAppShare = value; }
    //    }

    //    public string ConferenceName
    //    {
    //        get { return _conferenceName; }
    //        set { _conferenceName = value; }
    //    }

    //    public string ServerUrl
    //    {
    //        get { return _serverUrl; }
    //        set { _serverUrl = value; }
    //    }

    //    //public string SosServerUrl
    //    //{
    //    //    get { return _sosServerUrl; }
    //    //    set { _sosServerUrl = value; }
    //    //}

    //    public string UserName
    //    {
    //        get { return _userName; }
    //        set { _userName = value; }
    //    }

    //    public string UserType
    //    {
    //        get { return _userType; }
    //        set { _userType = value; }
    //    }

    //    public int VideoBandwidth
    //    {
    //        get { return _videoBandwidth; }
    //        set { _videoBandwidth = value; }
    //    }

    //    public int VideoQuality
    //    {
    //        get { return _videoQuality; }
    //        set { _videoQuality = value; }
    //    }

    //    public bool UseJavascript
    //    {
    //        get { return _useJavascript; }
    //        set { _useJavascript = value; }
    //    }

    //    public bool ShowVideoSelection
    //    {
    //        get { return _showVideoSelection; }
    //        set { _showVideoSelection = value; }
    //    }

    //    public bool SendMicSound
    //    {
    //        get { return _sendMicSound; }
    //        set { _sendMicSound = value; }
    //    }

    //    public bool ReceiveSound
    //    {
    //        get { return _receiveSound; }
    //        set { _receiveSound = value; }
    //    }

    //    public String CrmUserName
    //    {
    //        get { return Settings.Default.CrmUserName; }
    //    }

    //    public String CrmUserPassword
    //    {
    //        get { return Settings.Default.CrmUserPassword; }
    //    }

    //    public String CrmServiceUrl
    //    {
    //        get { return Settings.Default.CrmServiceUrl; }
    //    }

    //    public String LoginServiceUrl
    //    {
    //        get { return Settings.Default.LoginServiceUrl; }
    //    }

    //    public bool IgnoreCrm
    //    {
    //        get { return Settings.Default.IgnoreCrm; }
    //    }

    //    public int ScreenVideoWidth
    //    {
    //        get { return _screenVideoWidth; }
    //        set { _screenVideoWidth = value; }
    //    }

    //    public int ScreenVideoHeight
    //    {
    //        get { return _screenVideoHeight; }
    //        set { _screenVideoHeight = value; }
    //    }

    //    public bool VideoTransmitterMode
    //    {
    //        get { return _videoTransmitterMode; }
    //        set { _videoTransmitterMode = value; }
    //    }

    //    public bool KeepAspectRatioForVideo
    //    {
    //        get { return _keepAspectRatioForVideo; }
    //        set { _keepAspectRatioForVideo = value; }
    //    }


    //        public ConferenceStartupParameters()
    //        {
    //            _serverUrl = "rtmp://orby01.soslivecoach.com:2037/SosAvControlServer";
    //        }
    

    //}




}
